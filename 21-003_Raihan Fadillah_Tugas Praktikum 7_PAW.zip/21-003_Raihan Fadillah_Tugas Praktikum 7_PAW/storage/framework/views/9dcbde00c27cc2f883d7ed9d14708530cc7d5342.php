
<?php $__env->startSection('konten'); ?>
<head>
 <title>Home</title>
 <style>
    .container{
        width: 800px;
        text-align: justify;
    }
    h1{
        text-align: center;
    }
 </style>
</head>
<body>

    <div class="container">
        <h1>Universitas Trunojoyo Madura, Teknik Informatika And Why </h1>
        <img src="<?php echo e(('img/2020-10-23.jpg')); ?>" width ='470px' heigt='370px'>
    
    <p>Universitas Trunojoyo atau Universitas Trunojoyo Madura atau UTM atau Unijoyo adalah
        perguruan tinggi negeri yang terletak di Kecamatan Kamal, Kabupaten Bangkalan, 
        Provinsi Jawa Timur, Pulau Madura, Indonesia. Universitas Trunojoyo Madura dahulu 
        merupakan universitas swasta yang resmi menjadi perguruan tinggi negeri berdasarkan
        Keputusan Presiden tanggal 5 Juli 2001.[1] Perguruan tinggi ini diresmikan pada 
        tanggal 23 Juli 2001 oleh Presiden Abdurrahman Wahid. Universitas Trunojoyo Madura 
        merupakan perguruan tinggi negeri ke-7 di Jawa Timur. Universitas Trunojoyo Madura 
        dibangun di atas lahan seluas 28,5 hektare, yang terletak lima kilometer dari
        Pelabuhan Kamal Madura dan 15 km dari Bangkalan.</p>
    <p>Teknik Informatika merupakan bidang ilmu yang mempelajari bagaimana menggunakan 
        teknologi komputer secara optimal guna menangani masalah transformasi atau pengolahan 
        data dengan proses logika. Di Jurusan Teknik Informatika kamu akan mempelajari 
        berbagai prinsip terkait ilmu komputer mulai dari proses perancangan, pengembangan, 
        pengujian, hingga evaluasi sistem operasi perangkat lunak. Selama kuliah kamu akan 
        banyak mengkaji pemrograman dan komputasi, dan dibekali pula dengan keterampilan 
        merancang perangkat lunak.</p>
    <p>teknik informatika universitas trunojoyo madura bukanlah tujuan saya pada awalnya. 
        berawal dari mimpi berkuliah jauh dari rumah,selayaknya orang perantauan pada umumnya.
        namun, pupus sebelum dimulai. restu orang tua dan keterbatasan "koneksi" menjadi kendalanya.
        lalu memutar otak dengan pesan berkuliah di perguruan tinggi negeri di pulau yang sama "madura".
        mau tidak mau universitas trunojoyo madura lah yang menjadi pilihan, perguruan tinggi negeri
        satu-satunya di pulau madura. alasannya agar dekat dengan keluarga dan jika ingin menjengukku 
        di tempat kos. ku carilah mana jurusan yang memang di bidangku. dengan bermodal lolos eligible
        snmptn di sekolahku, aku menepatkan hatiku di prodi teknik mekatronika dan teknik informatika
        di pilihan kedua sebagai formalitas saja. teknik mekatronika menjadi pilihan pertamaku karena
        aku punya saudara yang berkuliah di universitas trunojoyo madura dengan prodi yang sama.
        niatnya agar aku bisa belajar dan dapat contekan tugasnya dari semester ke semester dan lulus
        dengan tepat waktu dan tidak kesulitan. pada akhirnya niat dari awal sudah buruk, pada akhirnya
        hasil pun demikian. aku tertolak dan malah masuk di prodi yang awalnya hanya kuanggap sebagai
        "formalitas pengisian snmptn". teknik informatika, disinilah aku sampai saat ini semester 3
        dengan segala kisah di dalamnya.

    </p>
    </div>
</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.tampilan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\raiha\Documents\KULIAH\SEMESTER 3\PAW\Praktikum\modul7\resources\views/home.blade.php ENDPATH**/ ?>